#include <stdio.h>
#include <stdint.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>

struct shared_area {
    volatile uint64_t lock;
    int count;
};

#define STORAGE_ID    "/SHM_TEST"
#define STORAGE_SIZE  sizeof(struct shared_area)

int main(int argc, char *argv[])
{
	int res, fd;
	pid_t pid;
	struct shared_area *addr;

	pid = getpid();

	// get shared memory file descriptor (NOT a file)
	fd = shm_open(STORAGE_ID, O_RDONLY, S_IRUSR | S_IWUSR);
	if (fd == -1) {
		return -1;
	}

	// map shared memory to process address space
	addr = mmap(NULL, STORAGE_SIZE, PROT_READ, MAP_SHARED, fd, 0);
	if (addr == MAP_FAILED) {
		perror("mmap");
		return -1;
	}

    printf("./GET pid %d: Read from shared memory: %d\n", pid, addr->count);

    fd = shm_unlink(STORAGE_ID);

	return 0;
}
