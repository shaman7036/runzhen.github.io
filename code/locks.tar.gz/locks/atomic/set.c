#include <stdio.h>
#include <stdint.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>

/* share memory */
struct shared_area {
    volatile uint64_t lock;
    int count;
};

#define STORAGE_ID    "/SHM_TEST"
#define STORAGE_SIZE  sizeof(struct shared_area)

#define SMP_LOCK "lock;"

static inline uint64_t
atomic_cmp_set(volatile uint64_t *lock, uint64_t old, uint64_t set)
{
    uint8_t  res;

    __asm__ volatile (

         SMP_LOCK
    "    cmpxchgq  %3, %1;   "
    "    sete      %0;       "

    : "=a" (res) : "m" (*lock), "a" (old), "r" (set) : "cc", "memory");

    return res;
}

void atomic_lock(struct shared_area *m, uint64_t pid)
{
    for (;;) {
        if (m->lock == 0 && atomic_cmp_set(&m->lock, 0, pid)) {
            return;
        }
    }
}

void atomic_unlock(struct shared_area *m, uint64_t pid)
{
    atomic_cmp_set(&m->lock, pid, 0);
}

int main(int argc, char *argv[])
{
	int res, fd, len;
	pid_t pid;
	struct shared_area *addr;

    printf("[+] SET PID %d start \n", getpid());

	// get shared memory file descriptor (NOT a file)
	fd = shm_open(STORAGE_ID, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
	if (fd == -1) {
		return -1;
	}

	// extend shared memory object as by default it's initialized with size 0
	res = ftruncate(fd, sizeof(struct shared_area));
	if (res == -1) {
		return -1;
	}

	// map shared memory to process address space
	addr = mmap(NULL, STORAGE_SIZE, PROT_WRITE, MAP_SHARED, fd, 0);
	if (addr == MAP_FAILED) {
		return -1;
	}

    atomic_lock(addr, getpid());
    for (int i = 0; i < 10000; i++) {
        usleep(10);
        addr->count += 1;
    }
    atomic_unlock(addr, getpid());

done:
	// mmap cleanup
	res = munmap(addr, STORAGE_SIZE);
	if (res == -1) {
		return -1;
	}

	return 0;
}
