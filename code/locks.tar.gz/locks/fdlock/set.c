#include <stdio.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>

/* share memory */
struct shared_area {
    int count;
};

#define STORAGE_ID    "/SHM_TEST"
#define STORAGE_SIZE  sizeof(struct shared_area)

/* file lock */
struct fdmutex {
    int fd;
};

void open_lock_file(struct fdmutex *m, char *name)
{
    m->fd = open(name, O_RDWR|O_CREAT|O_TRUNC, 0644);
}

void close_lock_file(struct fdmutex *m)
{
    close(m->fd);
}

void mtx_file_lock(struct fdmutex *m)
{
    struct flock fl;
    memset(&fl, 0, sizeof(struct flock));

    fl.l_type = F_WRLCK;
    fl.l_whence = SEEK_SET;

    if (fcntl(m->fd, F_SETLKW, &fl) == -1) {
        printf("[-] PID %d, lock failed (%s).\n", getpid(), strerror(errno));
    }
}

void mtx_file_unlock(struct fdmutex *m)
{
    struct flock fl;
    memset(&fl, 0, sizeof(struct flock));

    fl.l_type = F_UNLCK;
    fl.l_whence = SEEK_SET;

    if (fcntl(m->fd, F_SETLK, &fl) == -1) {
        printf("[-] PID %d, unlock failed (%s).\n", getpid(), strerror(errno));
    }
}

int main(int argc, char *argv[])
{
	int res, fd, len;
	pid_t pid;
	struct shared_area *addr;
    struct fdmutex mu;

    printf("[+] PID %d start \n", getpid());

	// get shared memory file descriptor (NOT a file)
	fd = shm_open(STORAGE_ID, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
	if (fd == -1) {
		return -1;
	}

	// extend shared memory object as by default it's initialized with size 0
	res = ftruncate(fd, sizeof(int));
	if (res == -1) {
		return -1;
	}

	// map shared memory to process address space
	addr = mmap(NULL, STORAGE_SIZE, PROT_WRITE, MAP_SHARED, fd, 0);
	if (addr == MAP_FAILED) {
		return -1;
	}

    open_lock_file(&mu, "./fd.lock");

    mtx_file_lock(&mu);
    for (int i = 0; i < 10000; i++) {
        addr->count += 1;
        usleep(10);
    }
    mtx_file_unlock(&mu);

done:
	// mmap cleanup
	res = munmap(addr, STORAGE_SIZE);
	if (res == -1) {
		return -1;
	}
    close_lock_file(&mu);

	return 0;
}
